=begin 
      La extension .to_i traduce el texto como a valores enteros
=end
puts " ------------------------------Calculadora-------------------------------------"
puts " #                       DESARROLLADO POR DD2XALPHA                           #"
puts " ##############################################################################"
puts " "
puts " Operaciones reconocibles: +, -, *, x, /"
puts " "
puts " Introduce el primer valor"
val1 = gets.chomp
val1 = val1.to_i
puts " Introduce operacion"
oper = gets.chomp
puts " Introduce el segundo valor"
val2 = gets.chomp
val2 = val2.to_i
puts " ="
if oper == "+"
     puts val1 + val2
end
if oper == "-"
	puts val1 - val2
end
if oper == "*"
	puts val1 * val2
end
if oper == "x"
	puts val1 * val2
end
if oper == "/"
	puts val1 / val2
end
puts "Pulsa enter para salir"
salir = gets.chomp